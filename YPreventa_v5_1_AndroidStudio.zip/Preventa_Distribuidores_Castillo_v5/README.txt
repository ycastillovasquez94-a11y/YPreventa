YPREVENTA — VERSIÓN 5

CONTENIDO
- web/: versión web para publicar en Netlify.
- android/: proyecto Android Studio para compilar el APK instalable.

CAMBIOS V5
1. Almacenamiento local persistente en IndexedDB del dispositivo, con respaldo compatible en localStorage.
2. Generación de preventa como imagen JPG y compartir por WhatsApp. En Android nativo se intenta dirigir el envío al número del cliente registrado; WhatsApp puede mostrar confirmación o selector según su versión.
3. Fecha de levantamiento y fecha de entrega mediante calendario.
4. Picking consolidado por FECHA DE ENTREGA, con formato de tira térmica 58/80 mm seleccionable en Ajustes.
5. Proyecto Android Studio instalable como APK.

IMPORTANTE SOBRE DATOS
- Los datos se guardan en el teléfono donde se usa la aplicación. No se sincronizan automáticamente con otros teléfonos.
- Antes de desinstalar o borrar datos de la app, exporte una copia JSON desde Ajustes.
- La copia JSON sigue siendo la forma recomendada de migrar información entre dispositivos.

GENERAR APK
1. Abrir la carpeta android/ con Android Studio (versión reciente).
2. Esperar la sincronización de Gradle y permitir la descarga de Android Gradle Plugin/AndroidX.
3. Menú Build > Build Bundle(s) / APK(s) > Build APK(s).
4. El APK de prueba queda en android/app/build/outputs/apk/debug/app-debug.apk.
5. Para distribuir fuera de pruebas, usar Build > Generate Signed Bundle / APK y firmar el APK.

PUBLICAR VERSIÓN WEB
Subir el contenido de web/ a Netlify. Para PWA, abrir el sitio con HTTPS y usar “Instalar aplicación” desde Chrome.

LIMITACIONES
- Este paquete incluye el proyecto Android listo para abrir/compilar, pero no contiene un APK ya compilado. El entorno de trabajo no tiene Android SDK/Gradle instalado para producir y probar el binario aquí.
- El envío a WhatsApp depende de que WhatsApp esté instalado y de las restricciones de la versión de Android/WhatsApp. Si el teléfono muestra la pantalla de compartir, seleccionar WhatsApp y el contacto.
- La impresión térmica usa el diálogo de impresión de Android/navegador; el controlador Bluetooth depende de la impresora instalada.
