package com.distribuidores.preventa;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.JavascriptInterface;
import android.content.Intent;
import android.net.Uri;
import android.widget.Toast;
import androidx.core.content.FileProvider;
import java.io.File;
import java.io.FileOutputStream;
import android.util.Base64;

public class MainActivity extends Activity {
    private WebView webView;
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setDatabaseEnabled(true);
        webView.getSettings().setAllowFileAccess(true);
        webView.getSettings().setAllowContentAccess(true);
        webView.setWebViewClient(new WebViewClient());
        webView.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }
    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
    public class AndroidBridge {
        @JavascriptInterface public void shareImageToWhatsApp(String phone, String base64, String filename, String message) {
            runOnUiThread(() -> {
                try {
                    byte[] bytes = Base64.decode(base64, Base64.DEFAULT);
                    File dir = new File(getCacheDir(), "shared"); dir.mkdirs();
                    File image = new File(dir, filename.replaceAll("[^a-zA-Z0-9._-]", "_"));
                    try (FileOutputStream out = new FileOutputStream(image)) { out.write(bytes); }
                    Uri uri = FileProvider.getUriForFile(MainActivity.this, getPackageName()+".fileprovider", image);
                    Intent send = new Intent(Intent.ACTION_SEND);
                    send.setType("image/jpeg");
                    send.putExtra(Intent.EXTRA_STREAM, uri);
                    send.putExtra(Intent.EXTRA_TEXT, message);
                    send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    String clean = phone == null ? "" : phone.replaceAll("[^0-9]", "");
                    if (!clean.isEmpty()) send.putExtra("jid", clean + "@s.whatsapp.net");
                    send.setPackage("com.whatsapp");
                    try { startActivity(send); }
                    catch (Exception notInstalled) {
                        send.setPackage(null);
                        startActivity(Intent.createChooser(send, "Compartir preventa JPG"));
                    }
                } catch (Exception ex) { Toast.makeText(MainActivity.this, "No se pudo compartir la imagen: "+ex.getMessage(), Toast.LENGTH_LONG).show(); }
            });
        }
    }
}
